<?php

return array(
    'lng.test' => 'Exemple de texte',
    'lng.test2' => 'Exemple de texte2',
);